const Joi = require('joi');
const { joiPasswordExtendCore } = require('joi-password');
const JoiPassword = Joi.extend(joiPasswordExtendCore);

const userSchema = Joi.object({
    name: Joi.string().min(5).required(),
    lastname: Joi.string().min(3).required(),
    email: Joi.string().email().required(),
    password: JoiPassword.string().min(8).max(15).minOfSpecialCharacters(1).minOfLowercase(1).minOfUppercase(1).minOfNumeric(1)
    .noWhiteSpaces().required(),
});

const loginSchema = Joi.object({
    email: Joi.string().email().required(),
    password: JoiPassword.string().min(8).max(15).minOfSpecialCharacters(1).minOfLowercase(1).minOfUppercase(1).minOfNumeric(1)
    .noWhiteSpaces().required(),
});

module.exports = { userSchema, loginSchema };