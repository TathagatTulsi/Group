const product = require("../models/ModelProduct");
const { Op } = require("sequelize")

exports.add = async (req, res) => {
    try {
        const { name, price, mfg, category, userId } = req.body;
        console.log("object", userId);
        const Seq = await product.create({ name, price, mfg, category, ownerId: userId })
        res.json({ Seq })
        console.log(Seq)
    } catch (error) {
        console.log(error)
    }
}


exports.get = async (req, res) => {
    try {

        const data = await product.findAll({ where: { ownerId: req.query.userId } });
        res.status(200).json({ data: data })
        console.log(data)

    } catch (error) {
        console.log(error)
    }

}

exports.search = async (req, res) => {
    try {

        const { name } = req.query;
        console.log(req.query)
        const results = await product.findAll({
            where: {

                [Op.and]: [
                    { ownerId: req.query.userId },
                    {
                        name: {
                            [Op.like]: `%${name}%`
                        }
                    }
                ]


            }
        })
        return res.json({ success: true, products: results })
    } catch (error) {

    }
}

exports.searchcategory = async (req, res) => {
    try {

        const { category } = req.query;
        console.log(req.query)
        const result = await product.findAll({
            where: {
                [Op.and]: [
                    { ownerId: req.query.userId },
                    {
                        category: {
                            [Op.like]: `%${category}%`
                        }
                    }
                ]
            }
        })
        return res.json({ success: true, products: result })
    } catch (error) {

    }
}

exports.deleted = async (req, res) => {
    try {
        const { productId } = req.query;
        const result = await product.destroy({
            where: { id: productId }
        })
        if (result) {
            // await result.destroy();
            return res.status(200).json({ message: 'deleted' })
        }
        return res.status(200).json({ message: "error" })


    } catch (error) {

    }
}
