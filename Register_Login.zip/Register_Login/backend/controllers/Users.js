const Users = require("../models/UserModel");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
// const { userSchema, loginSchema } = require("./joiValidation");

exports.Register = async (req, res) => {
  // //joi validation
  // const { error } = userSchema.validate(req.body);
  // if (error) return res.status(400).send(error.details[0].message);

  const { name, lastname, email, password, confPassword } = req.body;
  try {
    const find = await Users.findOne({
      where: { email },
    });

    if (find) {
      return res.status(200).json({ success: false, msg: "Already account" });
    }

    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(password, salt);

    const NewUser = await Users.create({ name, lastname, email, password: hash });
    const token = jwt.sign({ user: NewUser }, process.env.REFRESH_TOKEN_SECRET);

    return res.status(200).json({ success: true, msg: "Successfully!!", token: token });
  } catch (error) {
    console.log(error);
    return res.status(404).json({ msg: error });
  }
}

exports.Login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const find = await Users.findOne({
      where: {
        email,
      },
    });

    if (find) {
      const compare = bcrypt.compareSync(password, find.password);

      if (compare) {
        const token = jwt.sign({ user: find }, process.env.REFRESH_TOKEN_SECRET);

        return res.status(200).json({
          success: true,
          msg: "Login successfull!!",
          token: token,
        });
      }
    }
  } catch (error) {
    console.log(error);
    return res.status(404).json({ msg: error });
  }
}
