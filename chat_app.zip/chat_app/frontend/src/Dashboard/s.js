<div class='container-fluid'>
  <div class='row'>
    <div class='col-3 bg-secondary' style='height: 100vh; overflow-y: scroll;'>
      <div class='d-flex align-items-center my-4 mx-4'>
        <div>
          <img src={Img2} width={75} height={75} class='border border-primary p-2 rounded-circle' />
        </div>
        <div class='ml-4'>
          <h3 class='h4'>{user?.fullName}</h3>
          <p class='h6 font-weight-light'>My Account</p>
        </div>
      </div>
    </div>
    <div class='col'>
    
    </div>
  </div>
</div>
