import React from 'react'
import { useNavigate } from 'react-router-dom';
import logoutUser from '../token/logoutToken';
import {  toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
 
const Navbar = () => {
    const user = logoutUser()
    const navigate = useNavigate();
    
    const Logout = async () => {
        localStorage.clear()
           navigate("/login")
            toast.success('Logout Successfully!', {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
                });
    }
 
    return (
        <nav className="navbar is-light" role="navigation" aria-label="main navigation">
            <div className="container">
                <div className="navbar-brand">
                    <a className="navbar-item" href="/chatting">
                        <img src="cart.png" width="75" height="28" alt="logo" />
                    </a>
 
                </div>
 
                <div id="navbarBasicExample" className="navbar-menu">
                    <div className="navbar-start">
                        <a href="/chatting" className="navbar-item">
                            Home
                        </a>
                    </div>
 
                    <div className="navbar-end">
                        <div className="navbar-item">
                            <h4>{user.name}</h4>
                            <div className="buttons">
                                <button onClick={Logout} className="button is-light">
                                    Log Out
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    )
}
 
export default Navbar