const Users = require('../models/userModel');
const Conversations = require('../models/Conversations');
const Messages = require("../models/messageModel");


exports.conversation = async (req, res) => {
  try {
    const { senderId, receiverId } = req.body;
    const newCoversation = new Conversations({ members: [senderId, receiverId] });
    await newCoversation.save();
    res.status(200).send('Conversation created successfully');
} catch (error) {
    console.log(error, 'Error')
}
};

exports.message = async (req, res) => {
  
};

exports.users = async (req,res) => {

};