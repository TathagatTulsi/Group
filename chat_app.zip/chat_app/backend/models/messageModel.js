const { DataTypes } = require('sequelize');
const sequelize = require('../database/db');
const { Users } = require('./userModel')

const Messages = sequelize.define("message", {
  conversationId: {
    type: DataTypes.STRING,
  },
  message: {
    type: DataTypes.STRING
  },
  senderId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Users,
      key: 'id',
    },
  },
});

module.exports = Messages;