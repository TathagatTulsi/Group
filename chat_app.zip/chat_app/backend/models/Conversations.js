const { DataTypes } = require("sequelize");
const sequelize = require('../db/connection')

const Conversation = sequelize.define("conversation",{
    members: {
        type: DataTypes.ARRAY,
    }
});

module.exports = Conversation