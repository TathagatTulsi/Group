const Sequelize = require("sequelize");
const db = require("../config/db")
const { DataTypes } = Sequelize;

const Users = db.define('user',{
  name:{
      type: DataTypes.STRING,
      allowNull: false,
      validate: { len: [5, 15] }
      
  },
  email:{
      type: DataTypes.STRING,
      unique: true,
      allowNull: false,
      validate: { isEmail: true }
  },
  password:{
      type: DataTypes.STRING,
      allowNull: false,
  }
},
{
  freezeTableName:true
});

(async () => {
  await db.sync();
})();


module.exports = Users;