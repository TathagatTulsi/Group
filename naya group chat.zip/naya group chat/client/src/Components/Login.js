import React, { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';



function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();
   
    const handleSubmit = (event) => {
        event.preventDefault();
        axios.post('http://localhost:3500/login', { email, password })
          .then(res => {
            console.log(res)
            if (res.data.success === false) {
              alert(res.data.msg);
            }
            else {
            
              alert("Login Successfully")
              navigate("/chat")
            }
          })
          .catch(err => console.log(err));
      };

  return (
    <div>
    <section class="vh-100">
    <div class="container py-5 h-100">
    <div class="row d-flex align-items-center justify-content-center h-100">
    <h1 class="form-label" for="form1Example23">Giri<span style={{color:"#0059"}}>bot</span> </h1>
      <div class="col-md-8 col-lg-7 col-xl-6">
        <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.svg"
          class="img-fluid" alt="Phone image" />
      </div>
      <div class="col-md-7 col-lg-5 col-xl-5 offset-xl-1">
   
        <form  onSubmit={handleSubmit}>
          <div class="form-outline mb-4">
            <input type="email" id="form1Example13" class="form-control form-control-lg"  value={email}
            onChange={e => setEmail(e.target.value)}/>
            <label class="form-label" for="form1Example13">Email address</label>
          </div>

   
          <div class="form-outline mb-4">
            <input type="password" id="form1Example23" class="form-control form-control-lg"  value={password}
            onChange={e => setPassword(e.target.value)}/>
            <label class="form-label" for="form1Example23">Password</label>
          </div>

 
          <button type="submit" class="btn btn-primary btn-lg btn-block">Sign in</button>

        </form>
      </div>
    </div>
  </div>
</section>
</div>
  )
}

export default Login