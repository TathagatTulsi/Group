import React, { useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import ScrollToBottom from "react-scroll-to-bottom";
import "./Chat.css";
import axios from "axios";
import { useState } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:3500");
function Chat() {
  const user = JSON.parse(localStorage.getItem("user"));
  const [callConversation, setCallConversation] = useState([]);
  const [allMessage, setAllMessage] = useState([]);
  const [chat, setChat] = useState("");
  const [createConversation, setCreateConversation] = useState("");
  const [currentChat, setCurrentChat] = useState(null);
  const [member1, setMember1] = useState("");
  const [member2, setMember2] = useState("");

  const [data, setData] = useState([]);

  useEffect(() => {
    socket.emit("join chat", user.id);
    socket.on("receive message", (message) => {
      setAllMessage([...allMessage, message]);
      // console.log(message + "hdjs");
    });
  }, []);

  

  // send Message
  const sendMessage = (e) => {
    e.preventDefault();
    const getId = {
      usersId: user?.id,
      conversationId: currentChat?.id,
    };

    axios
      .post("http://localhost:3500/sendMessage", {
        contents: chat,
        conversationId: getId.conversationId,
        senderId: getId.usersId,
      })
      .then((res) => {
        //console.log(res);
        setAllMessage([...allMessage, res.data.newMessage]);
        socket.emit("send message", res.data.newMessage);
        setChat("");
      })
      .catch((err) => console.log(err));
  };

  // show chat
  const showChat = async (secondMem) => {
    //console.log(secondMem.id);
    const ifConvExist = callConversation?.find((c) => {
      // console.log("gh:", c);
      return (
        (c.chatapp_userModels[0].id === secondMem.id &&
          c.chatapp_userModels[1].id === user.id) ||
        (c.chatapp_userModels[1].id === secondMem.id &&
          c.chatapp_userModels[0].id === user.id)
      );
    });
    //console.log(ifConvExist);
    if (ifConvExist) {
      setCurrentChat(ifConvExist);
    } else {
      const res = await axios.post("http://localhost:3500/createConversation", {
        member1: user.id,
        member2: secondMem.id,
      });
      //console.log(res.data, "c");
      getConversation();
    }
  };

  // get Conversation
  const getConversation = () => {
    axios
      .get(`http://localhost:3500/conversation/${user.id}`)
      .then((response) => {
        //console.log("Conversation : ", response.data.conversations);
        setCallConversation(response.data.conversations);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  useEffect(() => {
    getConversation();
  }, []);

  // getUser
  const getUsers = () => {
    axios
      .get("http://localhost:3500/getUsers")
      .then((response) => {
        //console.log("users:", response.data);
        setData(response.data);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    getUsers();
  }, []);

  // how to get message
  const getMessage = () => {
    axios
      .get(`http://localhost:3500/messages/${currentChat?.id}`)
      .then((response) => {
        //console.log("message:", response.data.messages);
        setAllMessage(response.data.messages);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    getMessage();
  }, [currentChat]);

  return (
    <div>
      <div class="container-fluid">
      
        <div class="row">
        <div class="col-md-3 sidebar">
        <h3 class="py-3">User Listing</h3>
        

            {data.length > 0 &&
              data.map(
                (dataObj, index) =>
                  dataObj.id !== user.id && (
                    <ul class="user-list">
                      <button
                        class="user-list-item"
                        onClick={() => showChat(dataObj)}
                      >
                        {dataObj.name}
                      </button>
                    </ul>
                  )
              )}
          </div>

          <div class="col-md-9">
          <h3 class="py-3">Chat Messages</h3>
          {data.length > 0 &&
            data.map(
              (dataObj, index) =>
                dataObj.id === user.id && (
                  
                      
                      <h1> Welcome {dataObj.name}</h1>
                    
                 
                )
            )}
          <ScrollToBottom className = "card chat-messages">

         
                <div class="card-body">
                  <div class="message">
                    {currentChat && (
                      <div class="message-content">
                        <h1>
                          {
                            currentChat?.chatapp_userModels.find((dataObj) => {
                              return dataObj.id !== user.id;
                            }).name
                          }
                        </h1>
                      </div>
                    )}
                  </div>

                  <div class="message">
                    {allMessage.length > 0 &&
                      allMessage.map((dt, index) => {
                        return <div class="message-content">{dt.contents}</div>;
                      })}
                  </div>
                </div>
             
            </ScrollToBottom>
            <form class="mt-4 send-message-form" onSubmit={sendMessage}>
              <div class="input-group">
                <input
                  type="text"
                  class="form-control send-message-input"
                  placeholder="Type your message..."
                  aria-label="Type your message"
                  value={chat}
                  onChange={(e) => setChat(e.target.value)}
                />
                <button
                  class="btn btn-primary send-message-button"
                  type="submit"
                >
                  {" "}
                  Send
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
    </div>
  );
}

export default Chat;
