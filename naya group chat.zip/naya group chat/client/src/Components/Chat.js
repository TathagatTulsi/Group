import React , {useEffect} from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import './Chat.css';
import axios from 'axios';
import { useState } from 'react'
import {io} from "socket.io-client"

function Chat() {

  const socket = io("http://localhost:3500")
  const [data, setData] = useState([])


  const getImage = async () => {
		return await axios.get('http://localhost:3500/getUsers')
			.then((response) => {
				console.log("users:", response.data);
				setData(response.data)
			}).catch((err) => console.log(err))
	}

	useEffect(() => {
		getImage();
	}, []);


  return (
    <div>
    <div class="container-fluid">
    <div class="row">
   
      <div class="col-md-3 sidebar">
        <h3 class="py-3">User Listing</h3>
        {
          data.length > 0 && data.map((dataObj, index) => (
            <ul class="user-list">
            
                  <li class="user-list-item">{dataObj.name}</li>

              </ul>
          ))
      }
          
      </div>

      <div class="col-md-9">
        <h3 class="py-3">Chat Messages</h3>
        <div class="card chat-messages">
          <div class="card-body">
            <div class="message">
              <div class="message-sender">User 1:</div>
              <div class="message-content">Hello, how are you?</div>
            </div>
            <div class="message">
              <div class="message-sender">User 2:</div>
              <div class="message-content">I'm good, thanks! How about you?</div>
            </div>
            <div class="message">
              <div class="message-sender">User 1:</div>
              <div class="message-content">I'm doing great!</div>
            </div>
            <div class="message">
              <div class="message-sender">User 2:</div>
              <div class="message-content">That's good to hear!</div>
            </div>
          </div>
        </div>

    
        <form class="mt-4 send-message-form">
          <div class="input-group">
            <input type="text" class="form-control send-message-input" placeholder="Type your message..."
              aria-label="Type your message"/>
            <button class="btn btn-primary send-message-button" type="submit">Send</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
    </div>
  );
}

export default Chat;
