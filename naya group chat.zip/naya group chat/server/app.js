const express = require("express");
require('dotenv').config()
const http = require('http');
const {Server} = require('socket.io');
const app = express()
const server = http.createServer(app);
const port = 3500
require("./database/db")
var cors = require('cors')

const bodyParser = require('body-parser');
const appRoute = require('./Router/route');
const conversationRoutes = require("./Router/conversationRoute")
const messageRoutes = require("./Router/messageRoutes");



app.use(cors())
app.use(bodyParser.urlencoded({
    extended: false
}))
app.use(bodyParser.json())
// app.use(express.urlencoded({ extended: false }))
app.use('/', appRoute)
app.use('/',messageRoutes)
app.use("/", conversationRoutes)


// socket ka code

const corsOptions = {
    origin: "http://localhost:3000",
  };

const io = new Server(server, { cors: corsOptions });

io.on("connection", (socket) => {
  console.log("User connected!!");

  socket.on("join chat", (userId) => {
    socket.join(userId);
  });

  socket.on("send message", (message) => {
    console.log("Msg: ", message)
    socket.to(message.receiver.id).emit("receive message", {
      message,
    });
  });
});


server.listen(port, () => {
    console.log(`listening to the port no ${port}`)
})

