const ConversationModel = require("../model/Conversation");
const MessageUserModel = require("../model/messageUser");
const userModel = require("../model/userModel");

exports.sendMessage = async (req, res) => {
  try {
    const newMessage = await MessageUserModel.create(req.body);
    const findNewMessage = await MessageUserModel.findOne({
      include: [
        {
          model: ConversationModel,
          include: [
            {
              model: userModel,
            },
          ],
        },
        {
          model: userModel,
        },
      ],
      where: { id: newMessage.id },
    });

    return res.status(200).json({ success: true, newMessage: findNewMessage });
  } catch (error) {
    console.log(error);
  }
};

exports.findAllMessage = async (req, res) => {
  const { conversationId } = req.params;
  try {
    const messages = await MessageUserModel.findAll({
      include: [
        {
          model: ConversationModel,
          include: [
            {
              model: userModel,
            },
          ],
        },
        {
          model: userModel,
        },
      ],
      where: { conversationId },
    });
    return res.status(200).json({ success: true, messages });
  } catch (error) {
    console.log(error);
  }
};