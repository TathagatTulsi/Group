const ConversationModel = require("../model/Conversation");
const MessageUserModel = require("../model/messageUser");
const UserModel = require("../model/userModel");


exports.sendMsg = async (req, res) => {
  try {
    const newMessage = await MessageUserModel.create(req.body);
    const findNewMessage = await MessageUserModel.findOne(
      {
        where: {
          id: newMessage.id,
        },
      },
      { include: [ConversationModel, UserModel] }
    );

    return res.status(200).json({ success: true, newMessage: findNewMessage });
  } catch (error) {
    console.log(error);
  }
};

exports.findAllMsg = async (req, res) => {
  const { conversationId } = req.params;
  try {
    const messages = await MessageUserModel.findAll(
      { where: { conversationId } },
      { include: [
        {
            model : ConversationModel
        }
      ] }
    );

    console.log("first", messages)
    return res.status(200).json({ success: true, messages });
  } catch (error) {
    console.log(error);
  }
};
