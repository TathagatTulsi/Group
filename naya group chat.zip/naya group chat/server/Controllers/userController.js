const UserModel = require("../model/userModel");


exports.createUser = async (req, res) => {
    const { name, email, password } = req.body;
    console.log(req.body);
    const Seq = await UserModel.create({ name, email, password })
    res.json({ Seq })
    console.log(Seq)
}


exports.signup = async (req, res) => {
    console.log(req.body)

    var usr = {
        name: req.body.name,
        email: req.body.email,
        password: req.body.password,
    };
    created_user = await UserModel.create(usr);
    res.status(201).json(created_user);
}

// for login

exports.login = async (req, res) => {
    try {


        console.log(req.body)
        const user = await UserModel.findOne({ where: { email: req.body.email, password: req.body.password } });
        console.log(user)
        if (user) {

            res.status(200).json({ success: true, user: user , msg:"login successfully" });


        } else {
            res.status(404).json({ success: false, error: "User does not exist" });
        }
    } catch (error) {
        console.log(error)
    }
}

exports.getAllUsers =  async (req, res) => {
    try {
      // Fetch all users from the database
      const users = await UserModel.findAll();
  
      // Send the users as the API response
      res.json(users);
    } catch (error) {
      console.error('Error fetching users:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  };