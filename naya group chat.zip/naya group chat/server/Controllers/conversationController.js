const { Op } = require("sequelize");
const ConversationModel = require("../model/Conversation");
const ConvUserModel = require("../model/convUserModel");
const userModel = require("../model/userModel");


exports.createConversation = async (req, res) => {
  const { member1, member2 } = req.body;
  try {
    const newConversation = await ConversationModel.create();

    const users = await userModel.findAll({
      where: {
        id: [member1, member2],
      },
    });

    let convUser = [];
    users.map((us) => {
      let newObj = {
        userId: us.id,
        conversationId: newConversation.id,
      };
      convUser.push(newObj);
    });

    await ConvUserModel.bulkCreate(convUser);

    const conv = await ConversationModel.findOne({
      include: [
        {
          model: userModel,
          required: true,
          through: {
            where: {
              conversationId: newConversation.id,
            },
          },
        },
      ],
    });

    return res.status(200).json({
      success: true,
      msg: "Conversation created successfully!",
      conversation: conv,
    });
  } catch (error) {
    console.log(error);
  }
};

exports.findConversation = async (req, res) => {
  const { userId } = req.params;
  try {
    const conversations = await ConversationModel.findAll({
      include: userModel,
    });

    return res
      .status(200)
      .json({ success: true, conversations: conversations });
  } catch (error) {
    console.log(error);
  }
};

exports.fetchConversationUsingId = async (req, res) => {
  const { member1, member2 } = req.params;
  try {
    const conv = await ConversationModel.findAll({
      include: [
        {
          model: userModel,
          required: true,
          through: {
            where: {
              conversationId: 3,
            },
          },
        },
      ],
      distinct: true,
    });

    return res.status(200).json({ success: true, conv });
  } catch (error) {
    console.log(error);
  }
};
