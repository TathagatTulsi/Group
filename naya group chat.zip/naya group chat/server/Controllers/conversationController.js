const convUserModel = require("../model/convUserModel");
const ConversationModel = require("../model/Conversation");
const UserModel = require("../model/userModel");


exports.createConversation = async(req,res)=>{
    const {member1 , member2} = req.body;
    console.log(req.body);
    const conversation = await ConversationModel.create()
    const users = await UserModel.findAll({where:
    {
        id: [member1, member2]
    }
    })
    const arr= [];
    users.map((us)=>{
        let newObj = {
            userId:us.id , 
            conversationId: conversation.id
        }
    arr.push(newObj)
    })
    await convUserModel.bulkCreate(arr)
    console.log(conversation)
    return res.status(200).json({success:true, msg:"Conversation created successfully!!"})
}

exports.findConversation = async(req, res) => {
    const {userId} = req.params;
    try {
        const conversation = await ConversationModel.findAll({
            include : UserModel
        })

        return res.status(200).json({success:true, conversation})
    } catch (error) {
        console.log(error)
    }
}