const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require("../database/db");
const UserModel = require('./userModel');
const ConversationModel = require('./Conversation');



const MessageUserModel = sequelize.define('girichat_msgModel', {
    // Model attributes are defined here
    contents: {
        type: DataTypes.STRING,
        allowNull:false,
    },
    conversationId: {
        type: DataTypes.INTEGER,
        refrences: {
            model: ConversationModel,
            key: 'id'
        }
    }
    ,
    senderId: {
        type: DataTypes.INTEGER,
        refrences: {
            model: UserModel,
            key: 'id'
        }
    }
});
MessageUserModel.belongsTo(UserModel,{
    foreignKey:'senderId'
})

UserModel.hasMany(MessageUserModel,{
    foreignKey:'senderId'
})
MessageUserModel.belongsTo(ConversationModel,{
    foreignKey:'conversationId'
})
ConversationModel.hasMany( MessageUserModel, {
    foreignKey:'conversationId'
})

module.exports = MessageUserModel;