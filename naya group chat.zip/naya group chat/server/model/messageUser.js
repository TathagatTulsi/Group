const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require("../database/db");
const UserModel = require('./userModel');
const ConversationModel = require('./Conversation');



const MessageUserModel = sequelize.define('girichatapp_msgUserModel', {
    // Model attributes are defined here
    contents: {
        type: DataTypes.STRING,
        allowNull:false,
    },
    conversationId: {
        type: DataTypes.INTEGER,
        refrences: {
            model: ConversationModel,
            key: 'id'
        }
    }
    ,
    senderId: {
        type: DataTypes.INTEGER,
        refrences: {
            model: UserModel,
            key: 'id'
        }
    }
});
MessageUserModel.hasOne(UserModel,{
    foreignKey:'senderId'
})

UserModel.belongsTo(MessageUserModel,{
    foreignKey:'senderId'
})
MessageUserModel.hasOne(ConversationModel,{
    foreignKey:'conversationId'
})
ConversationModel.belongsTo( MessageUserModel, {
    foreignKey:'conversationId'
})

module.exports = MessageUserModel;