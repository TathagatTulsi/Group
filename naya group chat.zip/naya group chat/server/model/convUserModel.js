const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../database/db");
const ConversationModel = require("./Conversation");
const UserModel = require("./userModel");

const ConvUserModel = sequelize.define("chatapp_ConvUserModel", {
  // Model attributes are defined here
  userId: {
    type: DataTypes.INTEGER,
    references: {
      model: UserModel,
      key: "id",
    },
  },
  conversationId: {
    type: DataTypes.INTEGER,
    refrences: {
      model: ConversationModel,
      key: "id",
    },
  },
});

ConversationModel.belongsToMany(UserModel, {
  through: {
    model: ConvUserModel,
  },
  foreignKey: "conversationId",
});

UserModel.belongsToMany(ConversationModel, {
  through: {
    model: ConvUserModel,
  },
  foreignKey: "userId",
});

module.exports = ConvUserModel;
