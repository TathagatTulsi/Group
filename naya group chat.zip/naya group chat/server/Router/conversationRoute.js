const { createConversation, findConversation } = require("../Controllers/conversationController");

const router = require("express").Router();

router.post("/createConversation", createConversation);

router.get("/conversation/:userId", findConversation);

module.exports = router;