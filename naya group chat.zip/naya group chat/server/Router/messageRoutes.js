const {
  sendMessage,
  findAllMessage
  } = require("../Controllers/messageController");
  
  const router = require("express").Router();
  
  router.post("/sendMessage", sendMessage);
  router.get("/messages/:conversationId", findAllMessage);
  
  module.exports = router;