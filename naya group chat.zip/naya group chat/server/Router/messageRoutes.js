const {
    sendMsg,
    findAllMsg,
  } = require("../Controllers/messageController");
  
  const router = require("express").Router();
  
  router.post("/sendMessage", sendMsg);
  router.get("/messages/:conversationId", findAllMsg);
  
  module.exports = router;